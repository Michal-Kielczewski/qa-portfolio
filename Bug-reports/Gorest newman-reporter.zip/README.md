**Robot Framework Tests Result preview:
**
[First_web_scraping] https://michal-kielczewski.github.io/Robot-Framework/First_web_smoke_test_project/Test_Result.html

[Secound_web_smoke_test_project] https://michal-kielczewski.github.io/Robot-Framework/Secound_web_smoke_test_project/Results/log.html

[Login_validation_tests] https://michal-kielczewski.github.io/Robot-Framework/Login_validation_tests/Results/log.html
